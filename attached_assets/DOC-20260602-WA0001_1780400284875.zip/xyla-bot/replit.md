# Xyla Bot

A Discord moderation bot cloned from the original Xyla Bot ZIP, extended with a full **Whitelist** enforcement system that punishes non-whitelisted users who attempt to use moderation commands.

## Run & Operate

- Start the **"Xyla Bot"** workflow (set `DISCORD_TOKEN` env secret first)
- Dev command: `pnpm --filter @workspace/discord-bot run dev`
- Typecheck: `pnpm --filter @workspace/discord-bot run typecheck`

## Required env secrets

- `DISCORD_TOKEN` — your bot's token from the Discord developer portal
- `SESSION_SECRET` — already set (used by the API server)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Discord.js v14 + @discordjs/voice
- JSON file database (`bot-data.json`, handled by `src/database.ts`)
- tsx runner (no compile step needed for dev)
- Prefix: `!`, Bot Owner ID: `1391063304419545128`

## Where things live

- `artifacts/discord-bot/src/` — all bot source code
- `artifacts/discord-bot/src/commands/` — 24 command files (including `whitelist.ts`)
- `artifacts/discord-bot/src/utils/whitelist.ts` — `enforceWhitelist()` enforcement helper
- `artifacts/discord-bot/src/database.ts` — JSON DB with all whitelist functions
- `artifacts/discord-bot/src/index.ts` — entry point, loads all commands + events

## Whitelist System

The whitelist is an extra permission layer on top of Discord's built-in permissions. Even if someone has the Discord role/permission to ban/kick etc., if they're not whitelisted by the bot, they get **punished**.

**Exempt from enforcement:** bot owner, bot staff, server owner.

**Commands:**

| Command | Description |
|---|---|
| `!whitelist @user <perm>` | Whitelist a user for a specific permission |
| `!whitelistall @user` | Whitelist for ALL permissions at once |
| `!unwhitelist @user [perm]` | Remove from whitelist (all or specific) |
| `!whitelistcheck @user` | Check a user's whitelist status |
| `!whitelistlist` | List all whitelisted users in the server |
| `!setwhitelistpunishment <warn\|timeout\|kick\|ban>` | Set punishment for violations |
| `!whitelistperms` | Show all permission categories and current punishment |

**Permission categories:** `ban`, `kick`, `timeout`, `warn`, `mute`, `purge`, `slowmode`, `role`, `channel`, `nick`

**Enforcement coverage:**
- `ban` → ban, unban, hackban, massban, massunban
- `kick` → kick, masskick, vckick, vckickall
- `timeout` → timeout, untimeout, masstm, masstmremove
- `warn` → warn, masswarn, removewarn, warnleaderboard
- `mute` → chatmute, chatunmute, vcmute, vcunmute, vcmuteall, vcunmuteall, vcdeafen, vcundeafen, vcban, vcunban
- `purge` → purge, clear, prune
- `slowmode` → slowmode
- `role` → giverole, removerole, giveroleall
- `channel` → chatlock, chatunlock, lock, unlock, vchide, vcunhide

**Punishment types:**
- `warn` (default) — logs a bot warning
- `timeout` — 5-minute timeout
- `kick` — kicks from server
- `ban` — bans from server

## Custom Server Emojis in Embeds

The bot **can** use custom server emojis if it's a member of that server. Use the format:
```
<:emoji_name:emoji_id>
```
To get the emoji ID: type `\:emoji_name:` in Discord chat and copy the `<:name:id>` string.

Example in embed description: `"Status: <:online:123456789012345678>"`

## Architecture decisions

- JSON file DB (bot-data.json) persists all settings — no PostgreSQL needed
- Whitelist is stored as `guild_id -> user_id -> string[]` for O(1) per-permission lookups
- `enforceWhitelist()` returns `true` (blocked) or `false` (allowed) — command handlers `return` immediately when blocked
- Bot owner + server owner are always exempt; bot staff (developer/helper roles) are also exempt
- Punishment is per-guild configurable, defaults to `warn`

## Product

Xyla is a full-featured Discord moderation bot with:
- 24 command categories: Moderation, Mute, Fun, Percentage, Utility, Voice Bot, Music, Logs, Automod, Welcome, Temp VC, AFK, NSFW, Giveaway, Tickets, Setup, Jail, Server, Roles, Bio, Bot Owner, **Whitelist** (new)
- GIF reactions, games, truth/dare, music playback, giveaways, ticket system, jail system, automod, welcome messages, temp voice channels, AFK system, NSFW channels, and more

## User preferences

- Bot prefix: `!`
- Bot owner ID: `1391063304419545128`

## Gotchas

- The bot needs `DISCORD_TOKEN` env secret to start — it exits immediately otherwise
- Pre-existing TypeScript strict errors exist in the original bot code (botowner.ts, music.ts, etc.) — these don't affect runtime since tsx runs TypeScript directly without compiling
- Custom emojis only work if the bot is in the same server as the emoji
- The `bot-data.json` file is created automatically in the working directory on first run

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
