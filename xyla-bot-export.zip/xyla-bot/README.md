# Xyla Bot

Full-featured Discord bot — music, TTS, moderation, giveaways, tickets, temp VCs, AFK, whitelist, and more.

## Quick Start

```bash
# 1. Install dependencies
npm install
# or: pnpm install

# 2. Create your .env file
cp .env.example .env
# Edit .env — set DISCORD_TOKEN to your bot token

# 3. Run the bot
npm start
```

## Hosting (Railway / Render / VPS / any Node host)

| Setting | Value |
|---------|-------|
| Start command | `npm start` |
| Node version | 18+ (20 or 22 recommended) |
| Environment variable | `DISCORD_TOKEN=your_token` |
| Build command | *(none needed — uses tsx directly)* |

No database setup needed — data is stored in `bot-data.json` (created automatically).

## Bot Prefix
`!` (exclamation mark)

## Commands
Type `!help` in Discord to see all commands.
