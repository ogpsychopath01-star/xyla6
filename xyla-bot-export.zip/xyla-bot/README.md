# Xyla Bot

Full-featured Discord bot — music (YouTube + Spotify), TTS (24 languages), moderation, giveaways, tickets, temp VCs, AFK, whitelist, and much more.

## Hosting Setup

### Requirements
- **Node.js 18 or higher** (18, 20, or 22 all work)
- npm (comes with Node.js)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Set your bot token — create a .env file:
echo "DISCORD_TOKEN=your_token_here" > .env

# 3. Start the bot
npm start
```

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DISCORD_TOKEN` | ✅ Yes | Your Discord bot token from discord.com/developers |
| `SESSION_SECRET` | Optional | Any random string |

### Hosting Services (Railway / Render / Heroku / VPS)

| Setting | Value |
|---------|-------|
| **Start command** | `npm start` |
| **Build command** | `npm install` |
| **Node version** | 18 or higher |
| **Entry point** | `index.js` (already at root) |

No database needed — all data is saved automatically in `bot-data.json`.

## Bot Prefix
`!` — Example: `!play`, `!help`, `!tts hello`

## Commands
Type `!help` in Discord to see all 272 commands organized by category.

## Features
- 🎵 **Music** — YouTube, Spotify, queue, filters (bass boost, nightcore, slowed)
- 🔊 **TTS** — Text-to-speech in 24 languages with slow mode
- 🛡️ **Moderation** — ban, kick, mute, warn, purge, lock, automod
- 🎉 **Giveaways** — create, end, reroll
- 🎫 **Tickets** — full ticket system with logs
- 🔇 **Temp VCs** — auto-created/deleted voice channels
- 📊 **Stats** — voice time, message count, server leaderboard
- 💬 **AFK** — auto-notify when pinged while AFK
- 🔒 **Whitelist** — anti-abuse system
- 👤 **Bio / Jail / NSFW** — and much more
