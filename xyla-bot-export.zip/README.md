# Xyla Bot

Full-featured Discord bot — music (YouTube + Spotify), TTS (24 languages), moderation, giveaways, tickets, temp VCs, AFK, whitelist, and much more.

## Hosting Setup

### Requirements
- **Node.js 18 or higher** (18, 20, or 22 all work)
- npm (comes with Node.js)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Set your bot token — create a .env file:
echo "DISCORD_TOKEN=your_token_here" > .env

# 3. Start the bot
npm start
```

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DISCORD_TOKEN` | Yes | Your Discord bot token from discord.com/developers |
| `SESSION_SECRET` | Optional | Any random string |

### Start Command
`node index.js`
