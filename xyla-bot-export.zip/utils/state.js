let maintenanceMode = false;
const suspendedGuilds = new Set();
export function isMaintenanceMode() {
    return maintenanceMode;
}
export function setMaintenanceMode(value) {
    maintenanceMode = value;
}
// ── PER-GUILD SUSPENSION ─────────────────────────────────────────────────────
export function suspendGuild(guildId) {
    suspendedGuilds.add(guildId);
}
export function resumeGuild(guildId) {
    suspendedGuilds.delete(guildId);
}
export function isGuildSuspended(guildId) {
    return suspendedGuilds.has(guildId);
}
export function getSuspendedGuilds() {
    return Array.from(suspendedGuilds);
}
