import { PermissionFlagsBits } from 'discord.js';
import { getBotRole } from '../database.js';
export const BOT_OWNER_ID = '1391063304419545128';
export const PREFIX = '!';
export function isBotOwner(userId) {
    return userId === BOT_OWNER_ID;
}
export function isBotStaff(userId) {
    if (isBotOwner(userId))
        return true;
    const role = getBotRole(userId);
    return role === 'developer' || role === 'helper';
}
export function canModerate(mod, target) {
    if (mod.guild.ownerId === mod.id)
        return true;
    if (target.guild.ownerId === target.id)
        return false;
    return mod.roles.highest.comparePositionTo(target.roles.highest) > 0;
}
export function hasPermission(member, ...perms) {
    if (member.guild.ownerId === member.id)
        return true;
    return member.permissions.has(perms);
}
export const Perms = PermissionFlagsBits;
