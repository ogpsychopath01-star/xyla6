import { EmbedBuilder } from 'discord.js';
export const COLORS = {
    primary: 0x6C63FF, // Electric violet
    success: 0x2ECC71, // Emerald green
    error: 0xE74C3C, // Vivid red
    warning: 0xF39C12, // Amber
    info: 0x00D4FF, // Electric cyan
    nsfw: 0xFF006E, // Hot pink-red
    fun: 0xFF6EC7, // Neon pink
    moderation: 0xFF7043, // Deep orange
    logs: 0x5C6BC0, // Indigo
    giveaway: 0xFFD700, // Gold
    purple: 0x9B59B6, // Amethyst
    dark: 0x2C2F33, // Dark slate
    teal: 0x1ABC9C, // Teal
    gold: 0xF1C40F, // Golden yellow
};
export const BOT_OWNER_ID_DISPLAY = '1391063304419545128';
export const BOT_FOOTER = { text: `✦ Xyla Bot • Owner: ogpsychopath1 (ID: ${BOT_OWNER_ID_DISPLAY})` };
export function successEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle(`✅  ${title}`)
        .setDescription(description)
        .setFooter(BOT_FOOTER)
        .setTimestamp();
}
export function errorEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(COLORS.error)
        .setTitle(`❌  ${title}`)
        .setDescription(description)
        .setFooter(BOT_FOOTER)
        .setTimestamp();
}
export function infoEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(COLORS.info)
        .setTitle(`💠  ${title}`)
        .setDescription(description)
        .setFooter(BOT_FOOTER)
        .setTimestamp();
}
export function modEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(COLORS.moderation)
        .setTitle(title)
        .setDescription(description)
        .setFooter(BOT_FOOTER)
        .setTimestamp();
}
export function logEmbed(title, description, color = COLORS.logs) {
    return new EmbedBuilder()
        .setColor(color)
        .setTitle(title)
        .setDescription(description)
        .setFooter(BOT_FOOTER)
        .setTimestamp();
}
export function giveawayEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(COLORS.giveaway)
        .setTitle(`🎊  ${title}`)
        .setDescription(description)
        .setFooter(BOT_FOOTER)
        .setTimestamp();
}
export function warningEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(COLORS.warning)
        .setTitle(`⚠️  ${title}`)
        .setDescription(description)
        .setFooter(BOT_FOOTER)
        .setTimestamp();
}
