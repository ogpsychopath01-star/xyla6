import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = process.env.DB_PATH ?? path.join(__dirname, '..', 'bot-data.json');
let data = {
    warnings: [], mutes: {}, vc_bans: {}, afk: {},
    guild_settings: {}, log_settings: {}, automod_settings: {},
    welcome_settings: {}, leave_settings: {}, tempvc_settings: {},
    active_tempvcs: {}, nsfw_access: {}, nopfx_access: {}, bot_roles: {},
    voice_stats: {}, message_stats: {}, bot_247: {}, bios: {},
    giveaways: {}, bot_config: {},
    ticket_settings: {}, active_tickets: {}, ticket_counter: {},
    autoresponder: {}, autoreact: {}, temp_roles: [],
    automod_whitelist: {}, media_only_channels: {},
    jail_settings: {}, jailed_users: {},
    guild_banners: {}, guild_pfps: {},
    music_panels: {},
    whitelist_data: {},
    whitelist_punishment: {},
    whitelist_log: {},
    tts_user_langs: {},
    tts_guild_defaults: {},
    tts_user_slow: {},
};
let saveTimeout = null;
function load() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const raw = fs.readFileSync(DB_PATH, 'utf-8');
            const parsed = JSON.parse(raw);
            data = { ...data, ...parsed };
            if (!data.giveaways)
                data.giveaways = {};
            if (!data.bot_config)
                data.bot_config = {};
            if (!data.ticket_settings)
                data.ticket_settings = {};
            if (!data.active_tickets)
                data.active_tickets = {};
            if (!data.ticket_counter)
                data.ticket_counter = {};
            if (!data.autoresponder)
                data.autoresponder = {};
            if (!data.autoreact)
                data.autoreact = {};
            if (!data.temp_roles)
                data.temp_roles = [];
            if (!data.automod_whitelist)
                data.automod_whitelist = {};
            if (!data.media_only_channels)
                data.media_only_channels = {};
            if (!data.jail_settings)
                data.jail_settings = {};
            if (!data.jailed_users)
                data.jailed_users = {};
            if (!data.guild_banners)
                data.guild_banners = {};
            if (!data.guild_pfps)
                data.guild_pfps = {};
            if (!data.whitelist_data)
                data.whitelist_data = {};
            if (!data.whitelist_punishment)
                data.whitelist_punishment = {};
            if (!data.tts_user_langs)
                data.tts_user_langs = {};
            if (!data.tts_guild_defaults)
                data.tts_guild_defaults = {};
            if (!data.tts_user_slow)
                data.tts_user_slow = {};
        }
    }
    catch { /* fresh start */ }
}
function save() {
    if (saveTimeout)
        clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => {
        try {
            fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
        }
        catch { }
    }, 500);
}
load();
// ── GUILD SETTINGS ────────────────────────────────────────────────────────────
export function getSetting(guildId, key) {
    return data.guild_settings[guildId]?.[key] ?? null;
}
export function setSetting(guildId, key, value) {
    if (!data.guild_settings[guildId])
        data.guild_settings[guildId] = {};
    data.guild_settings[guildId][key] = value;
    save();
}
// ── LOG SETTINGS ──────────────────────────────────────────────────────────────
export function getLogChannel(guildId, logType) {
    return data.log_settings[guildId]?.[logType] ?? null;
}
export function setLogChannel(guildId, logType, channelId) {
    if (!data.log_settings[guildId])
        data.log_settings[guildId] = {};
    data.log_settings[guildId][logType] = channelId;
    save();
}
export function deleteLogChannel(guildId, logType) {
    if (data.log_settings[guildId])
        delete data.log_settings[guildId][logType];
    save();
}
// ── AUTOMOD SETTINGS ──────────────────────────────────────────────────────────
export function getAutomodSetting(guildId, feature) {
    return data.automod_settings[guildId]?.[feature];
}
export function setAutomodSetting(guildId, feature, enabled, punishment = 'warn', extra = '') {
    if (!data.automod_settings[guildId])
        data.automod_settings[guildId] = {};
    data.automod_settings[guildId][feature] = { enabled, punishment, extra };
    save();
}
// ── WARNINGS ──────────────────────────────────────────────────────────────────
let warnIdCounter = Math.max(0, ...(data.warnings.length ? data.warnings.map(w => w.id) : [0])) + 1;
export function addWarning(guildId, userId, reason, moderatorId) {
    data.warnings.push({ id: warnIdCounter++, guild_id: guildId, user_id: userId, reason, moderator_id: moderatorId, timestamp: Date.now() });
    save();
}
export function getWarnings(guildId, userId) {
    return data.warnings.filter(w => w.guild_id === guildId && w.user_id === userId).sort((a, b) => b.timestamp - a.timestamp);
}
export function getGuildWarnings(guildId) {
    return data.warnings.filter(w => w.guild_id === guildId);
}
export function removeWarnings(guildId, userId, count) {
    const userWarns = data.warnings.filter(w => w.guild_id === guildId && w.user_id === userId).sort((a, b) => b.timestamp - a.timestamp);
    const toRemove = count ? userWarns.slice(0, count).map(w => w.id) : userWarns.map(w => w.id);
    data.warnings = data.warnings.filter(w => !toRemove.includes(w.id));
    save();
}
// ── AFK ───────────────────────────────────────────────────────────────────────
export function isAfk(userId) {
    return data.afk[userId];
}
export function setAfk(userId, reason, dmNotifications) {
    data.afk[userId] = { reason, timestamp: Date.now(), dm_notifications: dmNotifications };
    save();
}
export function removeAfk(userId) {
    delete data.afk[userId];
    save();
}
// ── NSFW ACCESS ───────────────────────────────────────────────────────────────
export function hasNsfwAccess(userId, botOwnerId) {
    if (userId === botOwnerId)
        return true;
    const entry = data.nsfw_access[userId];
    if (!entry)
        return false;
    if (entry.expires_at > 0 && Date.now() > entry.expires_at) {
        delete data.nsfw_access[userId];
        save();
        return false;
    }
    return true;
}
export function grantNsfwAccess(userId, grantedBy, days) {
    data.nsfw_access[userId] = { granted_by: grantedBy, expires_at: days > 0 ? Date.now() + days * 86400000 : 0 };
    save();
}
export function revokeNsfwAccess(userId) {
    delete data.nsfw_access[userId];
    save();
}
export function getNsfwAccessInfo(userId) {
    return data.nsfw_access[userId];
}
// ── NO-PREFIX ACCESS ──────────────────────────────────────────────────────────
export function hasNoPfxAccess(userId, botOwnerId) {
    if (userId === botOwnerId)
        return true;
    const entry = data.nopfx_access[userId];
    if (!entry)
        return false;
    if (entry.expires_at > 0 && Date.now() > entry.expires_at) {
        delete data.nopfx_access[userId];
        save();
        return false;
    }
    return true;
}
export function grantNoPfxAccess(userId, grantedBy, days) {
    data.nopfx_access[userId] = { granted_by: grantedBy, expires_at: days > 0 ? Date.now() + days * 86400000 : 0 };
    save();
}
export function revokeNoPfxAccess(userId) {
    delete data.nopfx_access[userId];
    save();
}
export function getNoPfxAccessInfo(userId) {
    return data.nopfx_access[userId];
}
// ── BOT ROLES ─────────────────────────────────────────────────────────────────
export function getBotRole(userId) {
    return data.bot_roles[userId]?.role_type ?? null;
}
export function setBotRole(userId, roleType, assignedBy) {
    data.bot_roles[userId] = { role_type: roleType, assigned_by: assignedBy };
    save();
}
export function removeBotRole(userId) {
    delete data.bot_roles[userId];
    save();
}
export function getBotRoleUsers(roleType) {
    return Object.entries(data.bot_roles).filter(([, v]) => v.role_type === roleType).map(([user_id]) => ({ user_id }));
}
// ── VOICE STATS ───────────────────────────────────────────────────────────────
export function updateVoiceStats(guildId, userId, seconds) {
    if (!data.voice_stats[guildId])
        data.voice_stats[guildId] = {};
    const s = data.voice_stats[guildId][userId] ?? { daily: 0, weekly: 0, alltime: 0 };
    s.daily += seconds;
    s.weekly += seconds;
    s.alltime += seconds;
    data.voice_stats[guildId][userId] = s;
    save();
}
export function getVoiceStats(guildId, userId) {
    return data.voice_stats[guildId]?.[userId];
}
export function getAllVoiceStats(guildId) {
    const stats = data.voice_stats[guildId];
    if (!stats)
        return [];
    return Object.entries(stats).map(([userId, s]) => ({ userId, stats: s }));
}
export function setVoiceJoinTime(guildId, userId, time) {
    if (!data.voice_stats[guildId])
        data.voice_stats[guildId] = {};
    if (!data.voice_stats[guildId][userId])
        data.voice_stats[guildId][userId] = { daily: 0, weekly: 0, alltime: 0 };
    data.voice_stats[guildId][userId].last_join = time;
}
export function getVoiceJoinTime(guildId, userId) {
    return data.voice_stats[guildId]?.[userId]?.last_join;
}
export function resetVoiceStats(guildId, userId) {
    if (data.voice_stats[guildId]?.[userId]) {
        const lastJoin = data.voice_stats[guildId][userId].last_join;
        data.voice_stats[guildId][userId] = { daily: 0, weekly: 0, alltime: 0, last_join: lastJoin };
        save();
    }
}
export function resetAllVoiceStats(guildId) {
    if (data.voice_stats[guildId]) {
        for (const userId in data.voice_stats[guildId]) {
            const lastJoin = data.voice_stats[guildId][userId].last_join;
            data.voice_stats[guildId][userId] = { daily: 0, weekly: 0, alltime: 0, last_join: lastJoin };
        }
        save();
    }
}
// ── MESSAGE STATS ─────────────────────────────────────────────────────────────
export function updateMessageStats(guildId, userId) {
    if (!data.message_stats[guildId])
        data.message_stats[guildId] = {};
    const s = data.message_stats[guildId][userId] ?? { daily: 0, weekly: 0, alltime: 0 };
    s.daily++;
    s.weekly++;
    s.alltime++;
    data.message_stats[guildId][userId] = s;
    save();
}
export function getMessageStats(guildId, userId) {
    return data.message_stats[guildId]?.[userId];
}
export function getAllMessageStats(guildId) {
    const stats = data.message_stats[guildId];
    if (!stats)
        return [];
    return Object.entries(stats).map(([userId, s]) => ({ userId, stats: s }));
}
export function resetMessageStats(guildId, userId) {
    if (data.message_stats[guildId]?.[userId]) {
        data.message_stats[guildId][userId] = { daily: 0, weekly: 0, alltime: 0 };
        save();
    }
}
export function resetAllMessageStats(guildId) {
    if (data.message_stats[guildId]) {
        for (const userId in data.message_stats[guildId]) {
            data.message_stats[guildId][userId] = { daily: 0, weekly: 0, alltime: 0 };
        }
        save();
    }
}
// ── VC BAN ────────────────────────────────────────────────────────────────────
export function isVcBanned(guildId, userId) {
    return !!(data.vc_bans[`${guildId}:${userId}`]);
}
export function addVcBan(guildId, userId, reason, bannedBy) {
    data.vc_bans[`${guildId}:${userId}`] = { guild_id: guildId, user_id: userId, reason, banned_by: bannedBy };
    save();
}
export function removeVcBan(guildId, userId) {
    delete data.vc_bans[`${guildId}:${userId}`];
    save();
}
// ── WELCOME / LEAVE ───────────────────────────────────────────────────────────
export function getWelcomeSettings(guildId) { return data.welcome_settings[guildId]; }
export function setWelcomeSettings(guildId, s) { data.welcome_settings[guildId] = s; save(); }
export function getLeaveSettings(guildId) { return data.leave_settings[guildId]; }
export function setLeaveSettings(guildId, s) { data.leave_settings[guildId] = s; save(); }
// ── TEMP VC ───────────────────────────────────────────────────────────────────
export function getTempVcSettings(guildId) { return data.tempvc_settings[guildId]; }
export function setTempVcSettings(guildId, s) { data.tempvc_settings[guildId] = s; save(); }
export function updateTempVcSettings(guildId, patch) {
    if (!data.tempvc_settings[guildId])
        return;
    Object.assign(data.tempvc_settings[guildId], patch);
    save();
}
export function getActiveTempVc(channelId) { return data.active_tempvcs[channelId]; }
export function setActiveTempVc(channelId, t) { data.active_tempvcs[channelId] = t; save(); }
export function deleteActiveTempVc(channelId) { delete data.active_tempvcs[channelId]; save(); }
export function updateTempVc(channelId, patch) {
    if (data.active_tempvcs[channelId]) {
        Object.assign(data.active_tempvcs[channelId], patch);
        save();
    }
}
// ── BOT 24/7 ─────────────────────────────────────────────────────────────────
export function get247Channel(guildId) { return data.bot_247[guildId]; }
export function set247Channel(guildId, channelId) { data.bot_247[guildId] = channelId; save(); }
export function remove247Channel(guildId) { delete data.bot_247[guildId]; save(); }
export function getAll247() { return Object.entries(data.bot_247).map(([guild_id, channel_id]) => ({ guild_id, channel_id })); }
// ── BIO CARDS ─────────────────────────────────────────────────────────────────
export function getBio(guildId, userId) {
    return data.bios[guildId]?.[userId] || null;
}
export function setBio(guildId, userId, bio) {
    if (!data.bios[guildId])
        data.bios[guildId] = {};
    data.bios[guildId][userId] = bio;
    save();
}
// ── GIVEAWAYS ─────────────────────────────────────────────────────────────────
export function createGiveaway(messageId, channelId, guildId, prize, hostId, endTime, winnerCount) {
    data.giveaways[messageId] = { messageId, channelId, guildId, prize, hostId, endTime, winnerCount, ended: false, winners: [] };
    save();
}
export function getGiveaway(messageId) {
    return data.giveaways[messageId];
}
export function getAllGiveaways() {
    return data.giveaways ?? {};
}
export function endGiveawayInDB(messageId, winners) {
    if (data.giveaways[messageId]) {
        data.giveaways[messageId].ended = true;
        data.giveaways[messageId].winners = winners;
        save();
    }
}
export function deleteGiveaway(messageId) {
    delete data.giveaways[messageId];
    save();
}
// ── BOT CONFIG ────────────────────────────────────────────────────────────────
export function getBotConfig(key) {
    return data.bot_config[key];
}
export function setBotConfig(key, value) {
    data.bot_config[key] = value;
    save();
}
// ── DAILY / WEEKLY STAT RESET SCHEDULER ──────────────────────────────────────
function getMsUntilMidnight() {
    const now = new Date();
    const midnight = new Date(now);
    midnight.setHours(24, 0, 0, 0);
    return midnight.getTime() - now.getTime();
}
function getMsUntilNextMonday() {
    const now = new Date();
    const ms = getMsUntilMidnight();
    const daysUntilMonday = (8 - now.getDay()) % 7 || 7;
    return ms + (daysUntilMonday - 1) * 86400000;
}
export function startStatResetScheduler() {
    function scheduleDailyReset() {
        setTimeout(() => {
            for (const guildId in data.voice_stats) {
                for (const userId in data.voice_stats[guildId]) {
                    data.voice_stats[guildId][userId].daily = 0;
                }
            }
            for (const guildId in data.message_stats) {
                for (const userId in data.message_stats[guildId]) {
                    data.message_stats[guildId][userId].daily = 0;
                }
            }
            save();
            console.log('📅 Daily stats reset at midnight.');
            scheduleDailyReset();
        }, getMsUntilMidnight());
    }
    function scheduleWeeklyReset() {
        setTimeout(() => {
            for (const guildId in data.voice_stats) {
                for (const userId in data.voice_stats[guildId]) {
                    data.voice_stats[guildId][userId].weekly = 0;
                }
            }
            for (const guildId in data.message_stats) {
                for (const userId in data.message_stats[guildId]) {
                    data.message_stats[guildId][userId].weekly = 0;
                }
            }
            save();
            console.log('📆 Weekly stats reset on Monday.');
            scheduleWeeklyReset();
        }, getMsUntilNextMonday());
    }
    scheduleDailyReset();
    scheduleWeeklyReset();
}
// ── AUTORESPONDER ─────────────────────────────────────────────────────────────
export function getAutoresponder(userId) { return data.autoresponder[userId]; }
export function setAutoresponder(userId, msg) { data.autoresponder[userId] = msg; save(); }
export function removeAutoresponder(userId) { delete data.autoresponder[userId]; save(); }
// ── AUTOREACT ─────────────────────────────────────────────────────────────────
export function getAutoreact(userId) { return data.autoreact[userId]; }
export function setAutoreact(userId, emoji) { data.autoreact[userId] = emoji; save(); }
export function removeAutoreact(userId) { delete data.autoreact[userId]; save(); }
export function addTempRole(entry) {
    data.temp_roles = data.temp_roles.filter(r => !(r.guild_id === entry.guild_id && r.user_id === entry.user_id && r.role_id === entry.role_id));
    data.temp_roles.push(entry);
    save();
}
export function getExpiredTempRoles() {
    return data.temp_roles.filter(r => Date.now() >= r.expires_at);
}
export function removeTempRole(guildId, userId, roleId) {
    data.temp_roles = data.temp_roles.filter(r => !(r.guild_id === guildId && r.user_id === userId && r.role_id === roleId));
    save();
}
export function getTempRolesForUser(guildId, userId) {
    return data.temp_roles.filter(r => r.guild_id === guildId && r.user_id === userId);
}
// ── TICKET SYSTEM ─────────────────────────────────────────────────────────────
export function getTicketSettings(guildId) {
    return data.ticket_settings[guildId];
}
export function setTicketSettings(guildId, s) {
    data.ticket_settings[guildId] = s;
    save();
}
export function updateTicketSettings(guildId, patch) {
    if (!data.ticket_settings[guildId])
        return;
    Object.assign(data.ticket_settings[guildId], patch);
    save();
}
export function getActiveTicket(channelId) {
    return data.active_tickets[channelId];
}
export function getActiveTicketByUser(guildId, userId) {
    return Object.values(data.active_tickets).find(t => t.guild_id === guildId && t.user_id === userId);
}
export function createTicket(channelId, userId, guildId, type) {
    if (!data.ticket_counter[guildId])
        data.ticket_counter[guildId] = 0;
    data.ticket_counter[guildId]++;
    const num = data.ticket_counter[guildId];
    data.active_tickets[channelId] = { channel_id: channelId, user_id: userId, guild_id: guildId, type, created_at: Date.now(), ticket_number: num };
    save();
    return num;
}
export function deleteTicket(channelId) {
    delete data.active_tickets[channelId];
    save();
}
// ── AUTOMOD WHITELIST ─────────────────────────────────────────────────────────
export function getAutomodWhitelist(guildId) {
    return data.automod_whitelist[guildId] ?? [];
}
export function addAutomodWhitelist(guildId, channelId) {
    if (!data.automod_whitelist[guildId])
        data.automod_whitelist[guildId] = [];
    if (!data.automod_whitelist[guildId].includes(channelId)) {
        data.automod_whitelist[guildId].push(channelId);
        save();
    }
}
export function removeAutomodWhitelist(guildId, channelId) {
    if (!data.automod_whitelist[guildId])
        return;
    data.automod_whitelist[guildId] = data.automod_whitelist[guildId].filter(id => id !== channelId);
    save();
}
// ── MEDIA-ONLY CHANNELS ───────────────────────────────────────────────────────
export function getMediaOnlyChannels(guildId) {
    return data.media_only_channels[guildId] ?? [];
}
export function addMediaOnlyChannel(guildId, channelId) {
    if (!data.media_only_channels[guildId])
        data.media_only_channels[guildId] = [];
    if (!data.media_only_channels[guildId].includes(channelId)) {
        data.media_only_channels[guildId].push(channelId);
        save();
    }
}
export function removeMediaOnlyChannel(guildId, channelId) {
    if (!data.media_only_channels[guildId])
        return;
    data.media_only_channels[guildId] = data.media_only_channels[guildId].filter(id => id !== channelId);
    save();
}
export function isMediaOnlyChannel(guildId, channelId) {
    return (data.media_only_channels[guildId] ?? []).includes(channelId);
}
export function getJailSetting(guildId) {
    return data.jail_settings[guildId];
}
export function setJailSetting(guildId, s) {
    data.jail_settings[guildId] = s;
    save();
}
export function updateJailSetting(guildId, patch) {
    if (!data.jail_settings[guildId])
        return;
    Object.assign(data.jail_settings[guildId], patch);
    save();
}
export function getJailedUser(guildId, userId) {
    return data.jailed_users[`${guildId}:${userId}`];
}
export function setJailedUser(guildId, userId, entry) {
    data.jailed_users[`${guildId}:${userId}`] = entry;
    save();
}
export function removeJailedUser(guildId, userId) {
    delete data.jailed_users[`${guildId}:${userId}`];
    save();
}
export function getAllJailedUsers(guildId) {
    return Object.values(data.jailed_users).filter(j => j.guild_id === guildId);
}
// ── GUILD BANNERS / PFPS ──────────────────────────────────────────────────────
export function getGuildBanner(guildId) { return data.guild_banners[guildId]; }
export function setGuildBanner(guildId, url) { data.guild_banners[guildId] = url; save(); }
export function getGuildPfp(guildId) { return data.guild_pfps[guildId]; }
export function setGuildPfp(guildId, url) { data.guild_pfps[guildId] = url; save(); }
function getLikedStore() {
    if (!data.liked_songs)
        data.liked_songs = {};
    return data.liked_songs;
}
export function getLikedSongs(userId) {
    return getLikedStore()[userId] ?? [];
}
export function isLikedSong(userId, url) {
    return getLikedSongs(userId).some(s => s.url === url);
}
export function addLikedSong(userId, song) {
    const store = getLikedStore();
    if (!store[userId])
        store[userId] = [];
    if (!store[userId].some(s => s.url === song.url)) {
        store[userId].unshift(song);
        save();
    }
}
export function removeLikedSong(userId, url) {
    const store = getLikedStore();
    if (store[userId]) {
        store[userId] = store[userId].filter(s => s.url !== url);
        save();
    }
}
function getPlaylistStore() {
    if (!data.playlists)
        data.playlists = {};
    return data.playlists;
}
function playlistKey(userId, name) {
    return `${userId}::${name.toLowerCase()}`;
}
export function getUserPlaylists(userId) {
    const store = getPlaylistStore();
    return Object.values(store).filter(p => p.owner_id === userId);
}
export function getPlaylist(userId, name) {
    return getPlaylistStore()[playlistKey(userId, name)];
}
export function createPlaylist(userId, name) {
    const store = getPlaylistStore();
    store[playlistKey(userId, name)] = { name, owner_id: userId, songs: [], created_at: Date.now() };
    save();
}
export function deletePlaylist(userId, name) {
    delete getPlaylistStore()[playlistKey(userId, name)];
    save();
}
export function addToPlaylist(userId, name, song) {
    const pl = getPlaylistStore()[playlistKey(userId, name)];
    if (!pl)
        return;
    pl.songs.push(song);
    save();
}
export function removeFromPlaylist(userId, name, index) {
    const pl = getPlaylistStore()[playlistKey(userId, name)];
    if (!pl)
        return;
    pl.songs.splice(index, 1);
    save();
}
export function getPlaylistSong(userId, name, index) {
    return getPlaylistStore()[playlistKey(userId, name)]?.songs[index];
}
// ── MUSIC PANEL ───────────────────────────────────────────────────────────────
export function getMusicPanel(guildId) {
    return data.music_panels?.[guildId] ?? null;
}
export function setMusicPanel(guildId, channelId, messageId) {
    if (!data.music_panels)
        data.music_panels = {};
    data.music_panels[guildId] = { channel_id: channelId, message_id: messageId };
    save();
}
export function deleteMusicPanel(guildId) {
    if (data.music_panels) {
        delete data.music_panels[guildId];
        save();
    }
}
// ── GENERIC DB REF ────────────────────────────────────────────────────────────
export const db = { data };
// ── WHITELIST SYSTEM ──────────────────────────────────────────────────────────
export function isUserWhitelisted(guildId, userId, permission) {
    const perms = data.whitelist_data[guildId]?.[userId] ?? [];
    return perms.includes(permission) || perms.includes('all');
}
export function addUserWhitelist(guildId, userId, permission) {
    if (!data.whitelist_data[guildId])
        data.whitelist_data[guildId] = {};
    if (!data.whitelist_data[guildId][userId])
        data.whitelist_data[guildId][userId] = [];
    if (!data.whitelist_data[guildId][userId].includes(permission)) {
        data.whitelist_data[guildId][userId].push(permission);
        save();
    }
}
export function removeUserWhitelist(guildId, userId, permission) {
    if (!data.whitelist_data[guildId]?.[userId])
        return;
    if (!permission) {
        delete data.whitelist_data[guildId][userId];
    }
    else {
        data.whitelist_data[guildId][userId] = data.whitelist_data[guildId][userId].filter(p => p !== permission);
        if (!data.whitelist_data[guildId][userId].length)
            delete data.whitelist_data[guildId][userId];
    }
    save();
}
export function getUserWhitelistPerms(guildId, userId) {
    return data.whitelist_data[guildId]?.[userId] ?? [];
}
export function getGuildWhitelistMap(guildId) {
    return data.whitelist_data[guildId] ?? {};
}
export function getWhitelistPunishment(guildId) {
    return data.whitelist_punishment[guildId] ?? 'warn';
}
export function setWhitelistPunishment(guildId, punishment) {
    data.whitelist_punishment[guildId] = punishment;
    save();
}
// ── TTS LANGUAGE PREFERENCES ─────────────────────────────────────────────────
export function getTTSLang(userId) {
    return data.tts_user_langs?.[userId] ?? null;
}
export function setTTSLang(userId, lang) {
    if (!data.tts_user_langs)
        data.tts_user_langs = {};
    data.tts_user_langs[userId] = lang;
    save();
}
export function getTTSGuildDefault(guildId) {
    return data.tts_guild_defaults?.[guildId] ?? null;
}
export function setTTSGuildDefault(guildId, lang) {
    if (!data.tts_guild_defaults)
        data.tts_guild_defaults = {};
    data.tts_guild_defaults[guildId] = lang;
    save();
}
export function getTTSSlow(userId) {
    return data.tts_user_slow?.[userId] ?? false;
}
export function setTTSSlow(userId, value) {
    if (!data.tts_user_slow)
        data.tts_user_slow = {};
    data.tts_user_slow[userId] = value;
    save();
}
// ── WHITELIST AUDIT LOG ────────────────────────────────────────────────────────
export function addWhitelistLog(guildId, entry) {
    if (!data.whitelist_log)
        data.whitelist_log = {};
    if (!data.whitelist_log[guildId])
        data.whitelist_log[guildId] = [];
    data.whitelist_log[guildId].unshift(entry);
    if (data.whitelist_log[guildId].length > 50)
        data.whitelist_log[guildId].length = 50;
    save();
}
export function getWhitelistLog(guildId) {
    return data.whitelist_log?.[guildId] ?? [];
}
