import { Client, Collection, GatewayIntentBits, Partials } from 'discord.js';
export class BotClient extends Client {
    commands = new Collection();
    aliases = new Collection();
}
export function createClient() {
    const client = new BotClient({
        intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.GuildMembers,
            GatewayIntentBits.GuildBans,
            GatewayIntentBits.GuildVoiceStates,
            GatewayIntentBits.GuildPresences,
            GatewayIntentBits.MessageContent,
            GatewayIntentBits.DirectMessages,
            GatewayIntentBits.GuildModeration,
        ],
        partials: [Partials.Channel, Partials.Message, Partials.GuildMember],
    });
    return client;
}
